/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Beranda;

import connect.ConnectDb;
import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Beranda.formdata;

/**
 *
 * @author rakha
 */
public class DataAtlet extends javax.swing.JPanel {
    private final Connection conn = (Connection) new ConnectDb().connect();
    private  Dashboard main;
    
    public DataAtlet(Dashboard main) {
        initComponents();
        this.main = main;
       
        try {
            System.out.println(main.dataAtlet);
            loadData();
        } catch (SQLException ex) {
            Logger.getLogger(DataAtlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public DataAtlet() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        tbAt = new javax.swing.JScrollPane();
        tblAtlet = new javax.swing.JTable();
        bedit = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        cari = new javax.swing.JTextField();
        search = new javax.swing.JButton();
        bedit1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(44, 82, 130));
        setPreferredSize(new java.awt.Dimension(753, 1920));

        jPanel1.setBackground(new java.awt.Color(70, 100, 120));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Tabel Data Atlet");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 1550, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(248, 249, 250));

        tbAt.setBackground(new java.awt.Color(30, 30, 30));
        tbAt.setForeground(new java.awt.Color(30, 30, 30));
        tbAt.setFocusable(false);
        tbAt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbAtMouseClicked(evt);
            }
        });

        tblAtlet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "No", "Nama", "Jenis Kelamin", "Geup / Sabuk", "Dojang", "Tahun lahir"
            }
        ));
        tblAtlet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblAtletMouseClicked(evt);
            }
        });
        tbAt.setViewportView(tblAtlet);

        bedit.setBackground(new java.awt.Color(44, 82, 130));
        bedit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bedit.setForeground(new java.awt.Color(255, 255, 255));
        bedit.setText("Tambah Data");
        bedit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                beditMouseClicked(evt);
            }
        });
        bedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beditActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Cari :");

        cari.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });

        search.setBackground(new java.awt.Color(44, 82, 130));
        search.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        search.setForeground(new java.awt.Color(255, 255, 255));
        search.setText("Cari");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });

        bedit1.setBackground(new java.awt.Color(44, 82, 130));
        bedit1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bedit1.setForeground(new java.awt.Color(255, 255, 255));
        bedit1.setText("Edit Data");
        bedit1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bedit1MouseClicked(evt);
            }
        });
        bedit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bedit1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bedit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cari)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(tbAt, javax.swing.GroupLayout.PREFERRED_SIZE, 1545, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(bedit1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cari, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(9, 9, 9)
                .addComponent(tbAt, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bedit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bedit1)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Kandidat Atlet");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cariActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = new DefaultTableModel();
    model.addColumn("ID");
    model.addColumn("NAMA ATLET");
    model.addColumn("JENIS KELAMIN");
    model.addColumn("TTL");
    model.addColumn("BERAT BADAN");
    model.addColumn("TINGGI BADAN");
    model.addColumn("GEUP SABUK");
    model.addColumn("DOJANG");

    String keyword = cari.getText().trim();

    String sql = """
        SELECT 
            ID_ATLET,
            NAMA_ATLET,
            JENIS_KELAMIN,
            TTL,
            BERAT_BADAN,
            TINGGI_BADAN,
            GEUP_SABUK,
            DOJANG
        FROM TB_ATLET
        WHERE RECORD_FLAG <> 'D'
        AND (
            ID_ATLET LIKE ? OR
            NAMA_ATLET LIKE ?
        )
    """;

    try {
        PreparedStatement ps = (PreparedStatement) conn.prepareStatement(sql);

        String param = "%" + keyword + "%";

        ps.setString(1, param);
        ps.setString(2, param);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("ID_ATLET"),
                rs.getString("NAMA_ATLET"),
                rs.getString("JENIS_KELAMIN"),
                rs.getString("TTL"),
                rs.getString("BERAT_BADAN"),
                rs.getString("TINGGI_BADAN"),
                rs.getString("GEUP_SABUK"),
                rs.getString("DOJANG")
            });
        }

        tblAtlet.setModel(model);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error cari: " + e.getMessage());
    }
    }//GEN-LAST:event_searchActionPerformed

    private void beditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beditActionPerformed
        java.awt.Window parentWindow = javax.swing.SwingUtilities.getWindowAncestor(this);
        formdata popup = new formdata((java.awt.Frame) parentWindow, true, main);
        popup.setLocationRelativeTo(parentWindow);
        
        popup.setVisible(true);
        
    }//GEN-LAST:event_beditActionPerformed
    public void loadData() throws SQLException{
        DefaultTableModel model = new DefaultTableModel ();
        
        model.addColumn ("ID");
        model.addColumn ("Nama");
        model.addColumn ("Jenis");
        model.addColumn ("TTL");
        model.addColumn ("BB");
        model.addColumn ("TB");
        model.addColumn ("Geup");
        model.addColumn ("Dojang");
        
        try {
            String sql = """
                         select
                         a.id_atlet as id_atlet,
                         a.nama_atlet as nama_atlet,
                         a.jenis_kelamin as jenis_kelamin,
                         a.ttl as ttl,
                         a.berat_badan as berat_badan,
                         a.tinggi_badan as tinggi_badan,
                         a.geup_sabuk as geup_sabuk,
                         a.dojang as dojang 
                         from tb_atlet a 
                         where a.record_flag IS NULL OR a.record_flag <> 'D' 
                         order by a.id_atlet desc
                         """;
            PreparedStatement ps;
            ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){
                model.addRow(new Object []{
                    rs.getString("id_atlet"),
                    rs.getString("nama_atlet"),
                    rs.getString("jenis_kelamin"),
                    rs.getString("ttl"),
                    rs.getString("berat_badan"),
                    rs.getString("tinggi_badan"),
                    rs.getString("geup_sabuk"),
                    rs.getString("dojang")
                });
            }
            tblAtlet.setModel(model);
            tblAtlet.getColumnModel().getColumn(0).setMinWidth(0);
            tblAtlet.getColumnModel().getColumn(0).setMaxWidth(0);
            tblAtlet.getColumnModel().getColumn(0).setWidth(0);
           
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void beditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_beditMouseClicked
        
    }//GEN-LAST:event_beditMouseClicked

    private void tbAtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbAtMouseClicked

    }//GEN-LAST:event_tbAtMouseClicked

    private void tblAtletMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblAtletMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblAtletMouseClicked

    private void bedit1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bedit1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_bedit1MouseClicked

    private void bedit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bedit1ActionPerformed
        // TODO add your handling code here:
        int row = tblAtlet.getSelectedRow();
        int id = Integer.parseInt(tblAtlet.getValueAt(row, 0).toString());
        if (row == -1) {
        JOptionPane.showMessageDialog(this, "Pilih data dulu!");
        return;
        }

        String nama   = tblAtlet.getValueAt(row, 1).toString();
        String jenis  = tblAtlet.getValueAt(row, 2).toString();
        String ttl    = tblAtlet.getValueAt(row, 3).toString();
        String bb     = tblAtlet.getValueAt(row, 4).toString();
        String tb     = tblAtlet.getValueAt(row, 5).toString();
        String geup   = tblAtlet.getValueAt(row, 6).toString();
        String dojang = tblAtlet.getValueAt(row, 7).toString();

        java.awt.Window parentWindow = javax.swing.SwingUtilities.getWindowAncestor(this);
        formdata popup = new formdata((java.awt.Frame) parentWindow, true, main);

        
        popup.setEditData (id, nama, jenis, ttl, bb,tb,geup,dojang);
        popup.setLocationRelativeTo(parentWindow);
        popup.setVisible(true);
    }//GEN-LAST:event_bedit1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bedit;
    private javax.swing.JButton bedit1;
    private javax.swing.JTextField cari;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton search;
    private javax.swing.JScrollPane tbAt;
    private javax.swing.JTable tblAtlet;
    // End of variables declaration//GEN-END:variables
}
