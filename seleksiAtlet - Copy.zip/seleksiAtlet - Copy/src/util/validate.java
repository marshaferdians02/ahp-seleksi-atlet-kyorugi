/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.util.Date;
import javax.swing.JOptionPane;

public class validate {
    public static boolean validationAtlet (String namaAtlet, String jk, String lahir,String bb, String tb, String sabuk, String tempat){
        if (namaAtlet.isEmpty()){
            JOptionPane.showMessageDialog(null, "Nama Atlet tidak boleh kosong");
            return false;
        } else if (namaAtlet.length()< 0 && namaAtlet.length()> 128){
            JOptionPane.showMessageDialog(null, String.format("Nama Terlalu Panjang", namaAtlet.length()));
            return false;
        }
        if (jk.equalsIgnoreCase("Pilih")|| jk == null){
            JOptionPane.showMessageDialog(null, "Jenis Kelamin wajib di isi");
            return false;
        }
        if (lahir.isEmpty()){
            JOptionPane.showMessageDialog(null, "Tempat Lahir Tanggal Lahir twajib di isi");
            return false;
        }
        if (bb.isEmpty()){
            JOptionPane.showMessageDialog(null, " Berat Badan wajib di isi");
            return false;
        }
        if (tb.isEmpty()){
            JOptionPane.showMessageDialog(null, "Tinggi Badan wajib di isi");
            return false;
        }
        if (sabuk.isEmpty()){
            JOptionPane.showMessageDialog(null, "Geup wajib di isi");
            return false;
        }
        if (tempat.isEmpty()){
            JOptionPane.showMessageDialog(null, "Dojang wajib di isi");
            return false;
        }
        return true;
    }      
}
