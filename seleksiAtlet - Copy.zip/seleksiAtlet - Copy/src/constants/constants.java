/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.constants to edit this template
 */
package constants;

/**
 *
 * @author Marshanda Ferdians
 */
public interface constants {
    final  String RECORD_FLAG_N = "N";
    final  String RECORD_FLAG_U = "U";
    final  String RECORD_FLAG_D = "D";
}
